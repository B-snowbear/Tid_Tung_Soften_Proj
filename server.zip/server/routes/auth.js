import express from 'express';
import { createClient } from '@supabase/supabase-js';
import { randomInt } from 'crypto';

const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// Helper: 6-digit OTP
function genOtp() {
  return String(randomInt(100000, 999999));
}

// POST /api/auth/login → check email+password, create OTP, email it, return tempToken
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  // 1) Use Supabase to verify credentials
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error || !data.session) {
    return res.status(400).json({ message: 'Invalid email or password' });
  }

  const userId = data.user.id;

  // 2) Generate OTP + expiry + temp token, store in a table `login_otps` in Supabase
  const otp = genOtp();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

  const tempToken = crypto.randomUUID();

  const { error: insertError } = await supabase
    .from('login_otps')
    .insert({
      user_id: userId,
      otp_code: otp,
      expires_at: expiresAt,
      resend_count: 0,
      temp_token: tempToken,
    });

  if (insertError) {
    console.error(insertError);
    return res.status(500).json({ message: 'Failed to create OTP' });
  }

  // 3) TODO: send OTP via email (eg. Supabase function or external mail service)

  res.json({ tempToken });
});

// POST /api/auth/verify-otp → checks OTP + establishes final session (JWT or just return Supabase access token)
// POST /api/auth/resend-otp → up to 3 resends
// (same idea as earlier sample)
export default router;
